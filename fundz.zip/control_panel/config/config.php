<?php
session_start();
   define("host","localhost");
	define("username","b3m5z4q5_durshal");
	define("password","miandawood31");
	define("database","b3m5z4q5_durshal");

	//define("host","localhost");
	//define("username","root");
	//define("password","");
	//define("database","croweddurshal");
?>
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

<!-- Basic Stylesheets -->
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="assets/css/custom-style.css">
<link rel="stylesheet" type="text/css" href="assets/css/responsive.css">


<!-- Progressbar CSS -->
<link rel="stylesheet" href="assets/js/pieprogress/css/rainbow.css">
<link rel="stylesheet" href="assets/js/pieprogress/css/progress.css">

<!-- Revolution Slider CSS -->
<link rel="stylesheet" type="text/css" href="assets/js/slider-revolution/css/style.css" media="screen" />
<link rel="stylesheet" type="text/css" href="assets/js/slider-revolution/rs-plugin/css/settings.css" media="screen" />

<!-- Carousels CSS -->
<link href="assets/js/bxslider/jquery.bxslider.css" rel="stylesheet" />
<link type="text/css" rel="stylesheet" href="assets/css/medum.css">
<link rel="shortcut icon" type="image/png" href="assets/images/c.png"/>

<!-- Google Fonts & Font-Awesome -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:700,300,600,400" rel="stylesheet" type="text/css">
<link type="text/css" rel="stylesheet" href="assets/css/font-awesome.min.css" />
<link type="text/css" rel="stylesheet" href="assets/css/icons.css">

<!-- Your Custom Styles -->
<link rel="stylesheet" type="text/css" href="assets/css/my-styles.css">
 <link href="control_panel/bower_components/datetimepickers/css/bootstrap-datetimepicker.min.css" rel="stylesheet" type="text/css">

<script type="text/javascript" src="assets/js/jquery.js"></script>



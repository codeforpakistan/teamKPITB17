<script></script>


<script type="text/javascript" src="assets/js/migrate.js"></script>

<!-- Bootstrap Javascript -->
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>

<!-- Progressbar -->
<script type="text/javascript" src="assets/js/pieprogress/scripts/rainbow.min.js"></script>
<script type="text/javascript" src="assets/js/pieprogress/scripts/jquery-asPieProgress.js"></script>

<!-- Revolution Slider -->
<script type="text/javascript" src="assets/js/slider-revolution/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
<script type="text/javascript" src="assets/js/slider-revolution/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>

<!-- Carousels js -->
<script type="text/javascript" src="assets/js/bxslider/jquery.bxslider.min.js"></script>

<!-- Google Maps -->
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&amp;v=3.exp"></script>
<script type="text/javascript" src="assets/js/maps/scripts/jquery.gmap.min.js"></script>

<!--Custom Scroll Bar -->
<script type="text/javascript" src="assets/js/jquery.scroll.js"></script>
<script type="text/javascript" src="assets/js/medium.js"></script>

<!-- Grayscale Images -->
<script type="text/javascript" src="assets/js/jquery.hoverizr.min.js"></script>


<!-- Custom Settings -->
 <script type="text/javascript" src="assets/js/custom.js"></script> 

<!-- Jquery Plugins - (For Selectbox, EventCountDown) -->
 <script type="text/javascript" src="assets/js/plugin.js"></script>

<!-- Event Countdown -->
<script type="text/javascript" src="assets/js/countdown.js"></script>

<!-- Retina Script -->
<script type="text/javascript" src="assets/js/retina.min.js"></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.4.5/js/bootstrapvalidator.min.js'></script>

<!-- <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../../www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-90329424-1', 'auto');
  ga('send', 'pageview');

</script> -->
<script src="control_panel/bower_components/datetimepickers/js/moment.js"></script>
<script src="control_panel/bower_components/datetimepickers/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript" src="assets/js/excanvas.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.flot.js"></script>
<script type="text/javascript" src="assets/js/jquery.flot.resize.js"></script>
<script type="text/javascript" src="assets/js/jquery.flot.time.js"></script>
<script type="text/javascript" src="assets/js/jquery.flot.tooltip.min.js"></script>
 <script>
    $(document).ready(function() {
      if ($( ".input-group" ).hasClass( "date" )) {
        $('.date').datetimepicker({
            format: 'YYYY-MM-DD hh:mm:ss'
                });
      }
    })
</script>